%% Oving 2 -  part B

%Initialization 
f_0 = [0.5,0.5]'; %P(X_0) initial probability of rain and not rain 
T = [0.7, 0.3;
    0.3, 0.7];    % Transition matrix, the dynamic model
O_true = [0.9, 0; % Observation model if the umbrella shows up 
          0, 0.2];
O_false = eye(2) - O_true;  %Evidence model if the umbrella does not show up 

%% First part, prediction for the second day X_2
Evidence = [1,1]; %1 if umbrella showed up at day i
final_time = 2;
f = zeros(length(f_0),final_time+1); %initialize space for the finished result 
f(:,1) = f_0;

% FORWARD algorithm 
for i=1:final_time
    O_temp = O_false;
    if Evidence(i)
        O_temp = O_true;
    end
    f(:,i+1) = O_temp*T'*f(:,i);
    %Normalizing 
    f(:,i+1) = f(:,i+1)/(sum(f(:,i+1)));
end

%Displaying the probability of rain at day 2
disp('P(X_2 | e_{1:2}) = ');
disp(f(1,3));
disp('All normalized messages f_{1:2}');
disp(f(:,2:end));

%% Second part, prediction for the fifth day X_5
Evidence = [1,1,0,1,1];
final_time = 5;
f = zeros(length(f_0),final_time+1); %initialize space for the finished result 
f(:,1) = f_0;

% FORWARD algorithm 
for i=1:final_time
    O_temp = O_false;
    if Evidence(i)
        O_temp = O_true;
    end
    f(:,i+1) = O_temp*T'*f(:,i);
    %Normalizing 
    f(:,i+1) = f(:,i+1)/(sum(f(:,i+1)));
end

%Displaying the probability of rain at day 2
disp('P(X_5 | e_{1:5}) = ');
disp(f(1,5));
disp('All normalized messages f_{1:5}');
disp(f(:,2:end));
