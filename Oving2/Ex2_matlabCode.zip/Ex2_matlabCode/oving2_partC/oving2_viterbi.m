%% Viterbi
clear all
%Initialization 
T_true = [0.7;0.3];     % Transition matrix for when X is true and false
T_false = [0.3; 0.7];  
T = [T_true, T_false];
O_true = [0.9;0.2];     % Observation model if the umbrella shows up 
O_false = [0.1;0.8];    % Evidence model if the umbrella does not show up 
Evidence = [1,1,0,1,1]; % 1 if umbrella showed up at day i
final_time = 5;
m = zeros(length(T_true),final_time);
m(:,1) = [0.8182;0.1818];           % from the first step of FORWARD, just to have a starting point 
obs = O_false;
sequence = zeros(1,final_time);     %storing the sequence of most likely states that gave the observations

%% Viterbi
for i=2:final_time
    if Evidence(i)              %Find whether umbrella showed up or not
        obs = O_true; 
    else 
        obs = O_false;
    end 
    
    for j=1:2 
        T_temp = T(:,j);        %first do true, then false
        maximum = max(T_temp.*m(:,i-1));
        m(j,i) = obs(j)*maximum;
    end 
end

%Displaying the result of the messages 
disp('m_{1:t} = ');
disp(m);

%Tracebacking to find most likely sequence of states
for i=final_time:-1:1;
    if m(1,i) > m(2,i)
        sequence(i) = 1;
    else 
        sequence(i) = 0;
    end 
   
end

%Displaying the most likely sequemce of states
for j=1:final_time
    fprintf('Rain at day: %g, ',j);
    if sequence(j)
        disp('is most likely true');
    else
        disp('is most likely false');
    end
end