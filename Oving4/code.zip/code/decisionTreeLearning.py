import random 
import math
from collections import deque

numOfAttr = 7
numOfValuesForAttr = 2
numOfClass = 2

#Internal node in the tree, have split its children on the attribute splitOnAttr 
#and have subnodes children
class treeNode:
	def __init__(self,attr):
		self.splitOnAttr = attr
		self.children = {}


#Returns a matrix with one example on each row
def saveData(filename):
	output = []
	f = open(filename)
	for line in f:
		vec = []
		for elem in line.split( ):
			vec.append(int(elem)) #append the vector with the string as int
		output.append(vec)
	f.close()
	return output

#returning which class the majority of the examples are of
def pluralityValue(examples):
	classCount = [0]*numOfClass
	for ex in examples:
		classCount[ex[-1]-1] += 1
	return(classCount.index(max(classCount))+1)


#Finds whether all of the examples have same classification or not
def sameClass(examples):
	classValue = examples[0][-1]
	for ex in examples:
		if ex[-1] is not classValue:
			return False
	return True

#Finds a subset of the examples where attribute a have value v(1,2)
def findExWithAttrValue(examples,a,v):
	incidences = []
	for ex in examples:
		if ex[a] is v:
			incidences.append(ex)
	return incidences

#Must have in own function because can throw except if trying to evaluate log(0)
def calcEntropy(probabilityTrue):
	B = 0.0;
	probabilityFalse = 1-probabilityTrue
	try:
		B = -(probabilityTrue*math.log(probabilityTrue,2) \
			+ probabilityFalse*math.log(probabilityFalse,2))
	except:
		B = 0.0 
	return B

def importance(attributes,examples,gainImportance):
	if not gainImportance:
		bestA = random.randint(0,len(attributes)-1);
		return bestA

	#Calculating the current entropy of the examples 
	exOfClassValue1 = findExWithAttrValue(examples,-1,1)
	probClassValue1 = float(len(exOfClassValue1))/len(examples) 
	currentEntropy = calcEntropy(probClassValue1)

	#Calculating the expected reduction in entropy for each remaining attribute
	#Calculate remainder for each subset E which attribute 
	#A has divided eksamples into and sum them
	infoGain = []
	for A in attributes:
		remainder = 0.0
		for d in range(1,numOfValuesForAttr+1):
			E = findExWithAttrValue(examples,A,d)
			if E:
				p_k = len(findExWithAttrValue(E,-1,1)) 
				n_k = len(findExWithAttrValue(E,-1,2))	
				probPositive = float(p_k)/len(E) 
				#calculate entropy of these examples
				B_k = calcEntropy(probPositive)
				remainder += float(p_k+n_k)/len(examples)*B_k

		#information gain for attribute A
		infoGain.append(currentEntropy - remainder)
	bestA = infoGain.index(max(infoGain))
	return bestA


#Creates a decision tree from the examples using algorithm specified in book.
#gainImportance = True calculates importance for attribute using entropy, 
#False gives random allocation of importance 
def decisionTreeLearning(examples,attributes,parent_eksamples,gainImportance):
	if not examples:
		return pluralityValue(parent_eksamples)
	if sameClass(examples):
		return examples[0][-1] #class spesification at back of vector 
	if not attributes:
		return pluralityValue(examples)

	#Finds the most important attribute
	a = importance(attributes,examples,gainImportance) 
	A = attributes[a]

	#Create a new decision tree 
	tree = treeNode(A)
	#range over the different values for the attribute (1,2) 
	#and create a new branch with a subtree
	for v in range(1,numOfClass+1):
		ex = findExWithAttrValue(examples,a,v)
		subTree = decisionTreeLearning(ex,attributes,examples,gainImportance)
		tree.children[v] = subTree
	return tree

def traverseTree(root):
    print("Tree:")
    queue = deque([(root, ["Root"])])
    while queue:
        node, depth = queue.pop()
        if isinstance(node, int):
            r = "Classification %i" % (node)
        else:
            r = str(node.splitOnAttr+1) # +1 to print attributes 1-indexed
            for attVal, child in reversed(node.children.items()):
                queue.append((child, depth + ["%s" % attVal]))
        print("\t%s: %s" % ("->".join(depth), r))

def test(examples,tree):
	correctClassification = 0
	for ex in examples:
		correctClass = ex[-1]
		node = tree
		estimatedClass = 0 
		while True:
			if isinstance(node,int): 		
			#the leaves in the tree are nodes made of only one int, no children
				estimatedClass = node
				break
			A = node.splitOnAttr
			valueAttr = ex[A]
			if valueAttr not in node.children.keys(): 
				#we have no children, remember children is a dictionary (valueAttr,subtree)
				break 
			else:
				node = node.children[valueAttr] #continue traversing tree
		if estimatedClass == correctClass:
			correctClassification += 1
	probCorrect = float(correctClassification)/len(examples)
	print("Testing the tree we achieved correct classification on %i examples out of %i: " %(correctClassification,len(examples)))
	print("Thereby giving an accuracy of %f" %(probCorrect*100))

def main():
	print("Decision tree learning algorithm")
	trainingExamples = saveData("training.txt")
	attributes = list(range(numOfAttr)) #[0,1,2,3,4,5,6]
	testExamples = saveData("test.txt")

	print("Learning Random Tree...")
	treeRandom = decisionTreeLearning(trainingExamples,attributes,trainingExamples,False)
	print("Result of Tree:")
	traverseTree(treeRandom)
	test(testExamples, treeRandom)


	print("Learning Information Gain Tree...")
	treeInformationGain = decisionTreeLearning(trainingExamples,attributes,trainingExamples,True)
	print("Result of Tree")
	traverseTree(treeInformationGain)	
	test(testExamples,treeInformationGain)	
	
main()